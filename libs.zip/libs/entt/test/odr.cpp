#include <entt/entt.hpp> // IWYU pragma: keep
#include <entt/fwd.hpp>  // IWYU pragma: keep
