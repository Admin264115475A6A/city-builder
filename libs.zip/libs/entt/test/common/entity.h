#ifndef ENTT_COMMON_ENTITY_H
#define ENTT_COMMON_ENTITY_H

#include <cstdint>

namespace test {

enum entity : std::uint32_t {};
enum other_entity : std::uint32_t {};

} // namespace test

#endif
