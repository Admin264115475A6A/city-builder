#pragma once

#include <entt/entt.hpp> // Ensure this path is correct

struct Position {
    float x, y;
};

struct Velocity {
    float dx, dy;
};

class ECS {
public:
    entt::registry registry;

    entt::entity createEntity(float x, float y, float dx, float dy) {
        entt::entity entity = registry.create();
        registry.emplace<Position>(entity, x, y);
        registry.emplace<Velocity>(entity, dx, dy);
        return entity;
    }
};
