#include "InputManager.h"

GLFWwindow* InputManager::m_window = nullptr; // Define the static member

void InputManager::initialize(GLFWwindow* window) {
    m_window = window;
    glfwSetKeyCallback(m_window, keyCallback);
    glfwSetCursorPosCallback(m_window, mouseCallback);
}

void InputManager::keyCallback(GLFWwindow* window, int key, int scancode, int action, int mods) {
    if (action == GLFW_PRESS) {
        std::cout << "Key Pressed: " << key << std::endl;
    }
}

void InputManager::mouseCallback(GLFWwindow* window, double xpos, double ypos) {
    std::cout << "Mouse moved to: (" << xpos << ", " << ypos << ")" << std::endl;
}
