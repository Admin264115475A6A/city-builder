#ifndef INPUT_MANAGER_H
#define INPUT_MANAGER_H

#include <GLFW/glfw3.h>
#include <iostream>

class InputManager {
public:
    static void initialize(GLFWwindow* window);

private:
    static void keyCallback(GLFWwindow* window, int key, int scancode, int action, int mods);
    static void mouseCallback(GLFWwindow* window, double xpos, double ypos);

    static GLFWwindow* m_window; // Declare static member
};

#endif
