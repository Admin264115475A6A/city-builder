#include <glad/glad.h>
#include <GLFW/glfw3.h>
#include <iostream>
#include <thread>
#include <chrono>
#include "InputManager.h" // Ensure InputManager is implemented
#include "ECS.h" // Your ECS implementation

const int TARGET_FPS = 60;
const double FRAME_TIME = 1.0 / TARGET_FPS;

// Simple update function for movement
void update(ECS& ecs) {
    auto view = ecs.registry.view<Position, Velocity>();
    for (auto entity : view) {
        auto& pos = view.get<Position>(entity);
        auto& vel = view.get<Velocity>(entity);
        pos.x += vel.dx;
        pos.y += vel.dy;
    }
}

// OpenGL rendering function
void render(ECS& ecs) {
    glClear(GL_COLOR_BUFFER_BIT);

    auto view = ecs.registry.view<Position>();
    glBegin(GL_TRIANGLES);

    for (auto entity : view) {
        auto& pos = view.get<Position>(entity);

        glColor3f(1.0f, 0.0f, 0.0f); // Red
        glVertex2f(pos.x - 0.05f, pos.y - 0.05f);

        glColor3f(0.0f, 1.0f, 0.0f); // Green
        glVertex2f(pos.x + 0.05f, pos.y - 0.05f);

        glColor3f(0.0f, 0.0f, 1.0f); // Blue
        glVertex2f(pos.x, pos.y + 0.05f);
    }

    glEnd();
}

int main() {
    if (!glfwInit()) {
        std::cerr << "Failed to initialize GLFW!" << std::endl;
        return -1;
    }

    // Set OpenGL version (3.3) and compatibility profile
    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
    glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE); // Use core profile

    GLFWwindow* window = glfwCreateWindow(800, 600, "CityBuilder", NULL, NULL);
    if (!window) {
        std::cerr << "Failed to create window!" << std::endl;
        glfwTerminate();
        return -1;
    }

    glfwMakeContextCurrent(window);
    glfwSwapInterval(1); // Enable VSync

    // Initialize GLAD
    if (!gladLoadGLLoader((GLADloadproc)glfwGetProcAddress)) {
        std::cerr << "Failed to initialize GLAD!" << std::endl;
        return -1;
    }

    // Print OpenGL information AFTER GLAD is initialized
    std::cout << "Renderer: " << glGetString(GL_RENDERER) << std::endl;
    std::cout << "OpenGL Version: " << glGetString(GL_VERSION) << std::endl;

    InputManager::initialize(window);

    ECS ecs;
    auto entity = ecs.createEntity(0.0f, 0.0f, 0.002f, 0.002f);

    double lastTime = glfwGetTime();
    double accumulator = 0.0;

    while (!glfwWindowShouldClose(window)) {
        double currentTime = glfwGetTime();
        double deltaTime = currentTime - lastTime;
        lastTime = currentTime;
        accumulator += deltaTime;

        while (accumulator >= FRAME_TIME) {
            update(ecs); // Update ECS system
            accumulator -= FRAME_TIME;
        }

        glClear(GL_COLOR_BUFFER_BIT); // Clear before rendering
        render(ecs); // Render entities
        glfwSwapBuffers(window);
        glfwPollEvents();
    }

    glfwDestroyWindow(window);
    glfwTerminate();
    return 0;
}
