#pragma once
#include <entt/entt.hpp>

// Position Component
struct Position {
    float x, y;
};

// Velocity Component
struct Velocity {
    float dx, dy;
};

// Render Component (Just a placeholder for now)
struct Renderable {};
